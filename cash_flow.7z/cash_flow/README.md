# cash_flow
<p><b>Cash Flow Class Adalah Aplikasi Manajemen Uang Kas Berbasis Web Yang Di Bangun Menggunakan Bahasa Pemrogramman PHP+ Mysql Sebagai DBMS.
  Menggunakan Admin SB-2 Sebagai Admin Template, Source Ini Hanya Untuk Media Belajar Saja Dan Tidak Boleh Di Perjual belikan.</b></p>
  
  <b>Fitur:</b><br>
  <i>-Sistem Login & Logout</i><br>
  <i>-CRUD Manajemen Anggota</i><br>
  <i>-CRUD Manajemen Pemasukan</i><br>
  <i>-CRUD Manajemen Pengeluaran</i><br>
  <i>-Change Foto Dan Nama Admin</i><br>
  <i>-Change Password</i><br>
  
[![cashflow.png](https://i.postimg.cc/65GvpPZ2/cashflow.png)](https://postimg.cc/xcnCsttn)
