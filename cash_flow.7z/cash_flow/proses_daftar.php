<?php
include 'config/koneksi.php';
if(isset($_POST['daftar'])){
 $nama = $_POST['nama'];
 $username = $_POST['username'];
 $password = md5($_POST['password']);
 $kode = "2";
 $nidn = $_POST['nidn'];
 $email = $_POST['email'];
  // buat query
  $sql = "INSERT INTO konfirmasi (nama,username, password,kode,nidn,email) VALUE ('$nama','$username', '$password', '$kode','$nidn','$email')";
  $query = mysqli_query($conn, $sql);

  // apakah query simpan berhasil?
 if( $query ) {

    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
    header('Location: login.php');

 } else {
    // kalau gagal alihkan ke halaman indek.php dengan status=gagal
    header('Location: index.php?status=daftar_gagal');

 }
}
/*include 'config/koneksi.php';
if(isset($_POST['daftar'])){
 $nama = $_POST['nama'];
 $username = $_POST['username'];
 $password = md5($_POST['password']);
 $kode = "2";
 //$email = $_POST['email'];
 //$nidn = $_POST['nidn'];
  // buat query
  $sql = "INSERT INTO konfirmasi (nama,username, password,kode) VALUE ('$nama,$username', '$password', '$kode')";
  $query = mysqli_query($conn, $sql);

  // apakah query simpan berhasil?
 if( $query ) {

    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
    header('Location: login.php');

 } else {
    // kalau gagal alihkan ke halaman indek.php dengan status=gagal
    header('Location: login.php?status=daftar_gagal');

 }
}*/
?>
